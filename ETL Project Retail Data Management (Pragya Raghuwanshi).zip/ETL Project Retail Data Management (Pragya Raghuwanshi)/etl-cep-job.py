import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality
import gs_regex_extract
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import functions as SqlFuncs

def sparkAggregate(glueContext, parentFrame, groups, aggs, transformation_ctx) -> DynamicFrame:
    aggsFuncs = []
    for column, func in aggs:
        aggsFuncs.append(getattr(SqlFuncs, func)(column))
    result = parentFrame.toDF().groupBy(*groups).agg(*aggsFuncs) if len(groups) > 0 else parentFrame.toDF().agg(*aggsFuncs)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset used by all target nodes with data quality enabled
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Script generated for node AWS Glue Data Catalog
AWSGlueDataCatalog_node1765120435946 = glueContext.create_dynamic_frame.from_catalog(database="abc-retail", table_name="custproduct_details_csv", transformation_ctx="AWSGlueDataCatalog_node1765120435946")

# Script generated for node AWS Glue Data Catalog
AWSGlueDataCatalog_node1765120436275 = glueContext.create_dynamic_frame.from_catalog(database="abc-retail", table_name=" txntransactions_csv", transformation_ctx="AWSGlueDataCatalog_node1765120436275")

# Script generated for node Join
Join_node1765120454884 = Join.apply(frame1=AWSGlueDataCatalog_node1765120436275, frame2=AWSGlueDataCatalog_node1765120435946, keys1=["product id"], keys2=["productid"], transformation_ctx="Join_node1765120454884")

# Script generated for node Drop Fields
DropFields_node1765120728745 = DropFields.apply(frame=Join_node1765120454884, paths=["product id", "productid"], transformation_ctx="DropFields_node1765120728745")

# Script generated for node Regex Extractor
RegexExtractor_node1765120765557 = DropFields_node1765120728745.gs_regex_extract(colName="sales", regex=" \d+", newCols="NetSales")

# Script generated for node Aggregate
Aggregate_node1765120810185 = sparkAggregate(glueContext, parentFrame = RegexExtractor_node1765120765557, groups = ["ship mode", "product category"], aggs = [["sales", "avg"]], transformation_ctx = "Aggregate_node1765120810185")

# Script generated for node Amazon S3
EvaluateDataQuality().process_rows(frame=Aggregate_node1765120810185, ruleset=DEFAULT_DATA_QUALITY_RULESET, publishing_options={"dataQualityEvaluationContext": "EvaluateDataQuality_node1765120369209", "enableDataQualityResultsPublishing": True}, additional_options={"dataQualityResultsPublishing.strategy": "BEST_EFFORT", "observations.scope": "ALL"})
AmazonS3_node1765120839849 = glueContext.write_dynamic_frame.from_options(frame=Aggregate_node1765120810185, connection_type="s3", format="glueparquet", connection_options={"path": "s3://etl-cep-output-01pragya", "partitionKeys": []}, format_options={"compression": "snappy"}, transformation_ctx="AmazonS3_node1765120839849")

job.commit()